#!/bin/bash

sudo apt update -y

sudo apt upgrade -y

sudo apt autoremove
