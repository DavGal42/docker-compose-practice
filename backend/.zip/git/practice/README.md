# 🛠️ Practice

## Contents

🐍 **[Python](python)**

📝 **[Bash](bash-script)**
