export interface IResponseItem<T> {
  data: T;
}
