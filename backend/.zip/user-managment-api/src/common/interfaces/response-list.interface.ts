// import { PageMetaDto } from '../dto';

export interface IResponseList<T> {
    // _meta?: PageMetaDto;

    data: T[];
}
