export enum AppEnvironment {
  DEVELOPMENT = 'development',
  PRODUCTION = 'production',
  STAGING = 'staging',
  LOCAL = 'local',
  TEST = 'test'
}
