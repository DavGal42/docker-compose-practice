export const COMMON_ERROR_MESSAGES = {
  INVALID_ARGUMENTS: 'err_invalid_arguments',
};
