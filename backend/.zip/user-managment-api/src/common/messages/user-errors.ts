export const USER_ERROR_MESSAGES = {
  USER_PHONE_ALREADY_EXISTS: 'err_user_phone_already_exists',
  USER_EMAIL_ALREADY_EXISTS: 'err_user_email_already_exists',
  USER_PHONE_IN_USE: 'err_user_phone_in_use',
  USER_NOT_EXISTS: 'err_user_not_exists',
  USER_ALREADY_EXISTS: 'err_user_already_exists',
};
