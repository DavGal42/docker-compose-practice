import { USER_ERROR_MESSAGES } from './user-errors';

export const ERROR_MESSAGES = {
  ...USER_ERROR_MESSAGES,
};
