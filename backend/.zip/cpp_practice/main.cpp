#include <iostream>
int findSmallestMissing(int arr[], int n) {
    int left = 0, right = n - 1;
    while (left <= right) {
        int mid = (left + right) / 2;
        if (arr[mid] == mid) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    return left;
}
int main() {
    int n;
    std::cout << "Enter the number: ";
    std::cin >> n;
    if (n < 1) {
        std::cout << "Array must have at least 1 element." << std::endl;
        return 1;
    }
    int arr[n];
    std::cout << "Enter " << n << " sorted elements: ";
    for (int i = 0; i < n; i++) {
        std::cin >> arr[i];
    }
    int missingElement = findSmallestMissing(arr, n);
    std::cout << "The smallest missing element is: " << missingElement << std::endl;
    return 0;
}


